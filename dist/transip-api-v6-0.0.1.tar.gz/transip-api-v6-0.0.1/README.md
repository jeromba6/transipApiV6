# Transip-API-v6
---
This repo contains a package for Python3 to connect to the API of transip.

For more information about the Transip API go to https://api.transip.nl/rest/docs.html

Currently this is package mainly supports all actions on DNS. It can be easily extended.